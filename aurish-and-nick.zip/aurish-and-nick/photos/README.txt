PHOTOS
------
One picture per calendar day. Name it after the date: YYYY-MM-DD.jpg
Example: 2025-10-13.jpg  (shows when you tap the heart on 13 Oct 2025)
Want a caption, or a different file name? Add a line to PHOTOS in js/script.js.

TRAVEL LOG pictures (the date map): save them here too, for example photos/cafe.jpg,
then write  photo: "photos/cafe.jpg"  on that place in PLACES (js/script.js).
